/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.examen3evaluacion;

/**
 *
 * @author enriq
 */
public abstract class Vehiculos {
    protected String marca;
    protected String modelo;
    
    public Vehiculos(String marca, String modelo){
        this.marca = marca;
        this.modelo = modelo;
    }
    
    public void mostrarDatos(){
    System.out.println("Marca: " + marca);
    System.out.println("Modelo: " + modelo);
    }   
    
    public abstract void arrancar();
    
}
