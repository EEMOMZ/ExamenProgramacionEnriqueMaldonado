/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

    package com.mycompany.examen3evaluacion;
    import java.util.ArrayList;
    import java.util.Scanner;
    import java.util.List;

    /**
     *
     * @author enriq
     */
    public class appVehiculos {
    static Scanner sc = new Scanner(System.in);
        static List<Vehiculos> vehiculos = new ArrayList<>();

        public static void main(String[] args) {
            int opcion;
            do {
                System.out.println("\n Menu vehiculos");
                System.out.println("1. Agregar vehiculos");
                System.out.println("2. Mostrar vehiculos");
                System.out.println("0. Salir");
                System.out.println("Elige una opcion: ");
                opcion = sc.nextInt();
                sc.nextLine(); // limpiar buffer

                switch (opcion){
                    case 1: 
                        do{
                            System.out.println("\n Agregar Vehiculos");
                            System.out.println("1. Agregar Coche");
                            System.out.println("2. Agregar Moto");
                            System.out.println("3. Agregar Camion");
                            System.out.println("4. Agregar Patinete");
                            System.out.println("5. Agregar Bicicleta");
                            System.out.println("6. Volver al menu principal");
                            System.out.print("Selecciona una opcion: ");
                            opcion = sc.nextInt();

                            switch (opcion) {
                                case 1:
                                    vehiculos.add(crearVehiculos("Coche"));
                                    break;
                                case 2:
                                     vehiculos.add(crearVehiculos("Moto"));
                                     break;
                                case 3:
                                     vehiculos.add(crearVehiculos("Camion"));
                                     break;
                                case 4:
                                     vehiculos.add(crearVehiculos("Patinete"));
                                     break;
                                case 5:
                                     vehiculos.add(crearVehiculos("Bicicleta"));
                                     break;
                                case 6:
                                    System.out.println("Volviendo al menu principal...");
                                    break;
                                default:
                                    System.out.println("Opcion invalida, intenta de nuevo.");
                                    break;
                            }
                        } while (opcion != 6);
                        break;

                    case 2:
                        mostrarVehiculos();
                         break;

                    case 0:
                        System.out.println("Saliendo...");
                        break;

                    default:
                        System.out.println("Salida completada.");
                        break;
                }
            } while (opcion != 0);


        }

    static Vehiculos crearVehiculos(String tipo) {
        sc.nextLine(); // Limpiar buffer antes de leer el nombre
        System.out.print("Marca: ");
        String marca = sc.nextLine();

        System.out.print("Modelo: ");
        String modelo = sc.nextLine();

        return switch (tipo) {
            case "Coche" -> new Coche(marca, modelo);
            case "Moto" -> new Moto(marca, modelo);
            case "Camion" -> new Camion(marca, modelo);
            case "Patinete" -> new Patinete(marca, modelo);
            case "Bicicleta" -> new Bicicleta(marca, modelo);
            default -> null;
        };
    }

            static void mostrarVehiculos(){
                for(Vehiculos m : vehiculos){
                    m.mostrarDatos();
                    m.arrancar();
                    System.out.println("----");
                }
            }
    }
